import { income, liveUnits } from './state';
import { MAX_UNITS_PER_SIDE, type Game } from './types';

export interface HudHandlers {
  onEndTurn(): void;
  onNewGame(): void;
  onFitView(): void;
}

export interface ContextAction {
  label: string;
  disabled?: boolean;
  run(): void;
}

export interface Hud {
  setup(g: Game): void;
  update(g: Game): void;
  showError(text: string): void;
  showContext(x: number, y: number, infoHtml: string, actions: ContextAction[]): void;
  hideContext(): void;
  showInfo(html: string): void;
}

const el = <T extends HTMLElement>(id: string): T => {
  const e = document.getElementById(id);
  if (!e) throw new Error(`#${id} が見つかりません`);
  return e as T;
};

export function createHud(handlers: HudHandlers): Hud {
  const turnLabel = el('tn');
  const goldLabel = el('gd');
  const message = el('msg');
  const info = el('info');
  const catalog = el('recruit');
  const endTurn = el<HTMLButtonElement>('be');
  const newGame = el<HTMLButtonElement>('bn');
  const fitView = el<HTMLButtonElement>('bf');
  const ctx = el('ctx');

  endTurn.onclick = handlers.onEndTurn;
  newGame.onclick = handlers.onNewGame;
  fitView.onclick = handlers.onFitView;

  const panes: Array<[string, string]> = [
    ['tab-left', 'pane-left'],
    ['tab-right', 'pane-right'],
    ['tab-bottom', 'pane-bottom'],
  ];
  for (const [tabId, paneId] of panes) {
    el(tabId).addEventListener('click', () => {
      const pane = el(paneId);
      const willOpen = !pane.classList.contains('open');
      for (const [, otherId] of panes) el(otherId).classList.remove('open');
      if (willOpen) pane.classList.add('open');
    });
  }

  const hideContext = (): void => {
    ctx.hidden = true;
    ctx.replaceChildren();
  };
  document.addEventListener('pointerdown', (e) => {
    if (!ctx.hidden && !ctx.contains(e.target as Node)) hideContext();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') hideContext();
  });

  return {
    setup(g) {
      // 生産ペイン: ユニット一覧(生産そのものはマップ上の右クリックメニューから行う)
      catalog.replaceChildren();
      for (const def of Object.values(g.defs)) {
        const d = document.createElement('div');
        d.className = 'unit-row';
        d.textContent =
          `${def.name}(${def.domain === 'air' ? '航空' : '地上'}) ${def.cost}G / HP${def.hp} 移${def.move} 攻${def.attack} 防${def.defense} 射${def.minRange}〜${def.range}` +
          (def.canCapture ? ' / 占領可' : '');
        catalog.append(d);
      }
    },
    update(g) {
      turnLabel.textContent = `ターン ${g.turn}`;
      goldLabel.textContent = `資金 ${g.gold.p}(+${income(g, 'p')}) / 部隊 ${liveUnits(g, 'p').length}/${MAX_UNITS_PER_SIDE}`;
      message.textContent = g.message;
      endTurn.disabled = g.busy || g.over;
    },
    showError(text) {
      message.textContent = text;
      el('pane-bottom').classList.add('open');
    },
    showContext(x, y, infoHtml, actions) {
      ctx.replaceChildren();
      const infoDiv = document.createElement('div');
      infoDiv.className = 'ctx-info';
      infoDiv.innerHTML = infoHtml;
      ctx.append(infoDiv);
      for (const a of actions) {
        const b = document.createElement('button');
        b.textContent = a.label;
        b.disabled = !!a.disabled;
        b.onclick = () => {
          hideContext();
          a.run();
        };
        ctx.append(b);
      }
      ctx.hidden = false;
      const w = ctx.offsetWidth;
      const h = ctx.offsetHeight;
      ctx.style.left = `${Math.max(4, Math.min(x, window.innerWidth - w - 8))}px`;
      ctx.style.top = `${Math.max(4, Math.min(y, window.innerHeight - h - 8))}px`;
    },
    hideContext,
    showInfo(html) {
      info.innerHTML = html;
    },
  };
}
